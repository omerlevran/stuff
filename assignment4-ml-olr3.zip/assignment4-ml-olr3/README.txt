# Markov Decision Processes

Credit to https://github.com/cmaron/CS-7641-assignments cause I used most of his code.

In order to run, download the zip file from the following directory

Unzip the file

Cd into the directory

Run `pip install -r requirements.txt`

Run all experiments and plot them

`python run_experiment.py --all --plot`

This will create output/images and output/report which were used in the report