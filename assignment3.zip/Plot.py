import matplotlib.pyplot as plt
import numpy as np

from scipy import stats
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import learning_curve

import itertools

def plot_inertia_curve(figNum, clusters, inertias, axes, title):

    plt.figure(figNum)
    plt.plot(clusters, inertias) # cluster num (x axis), inertia (y axis)
    plt.axis(axes)
    plt.xlabel("Number of Clusters")
    plt.ylabel("k Means Inertia (Sum of Squared Distances)")
    plt.title(title)
    plt.tight_layout()
    plt.grid(True)
    plt.savefig(title.replace(" ", "_"))

    return


def plot_silhouettes_curve(figNum, clusters, silhouettes, axes, title):

    plt.figure(figNum)
    plt.plot(clusters, silhouettes) # cluster num (x axis), silhouettes (y axis)
    plt.axis(axes)
    plt.xlabel("Number of Clusters")
    plt.ylabel("k Means Silhouette Score")
    plt.title(title)
    plt.tight_layout()
    plt.grid(True)
    plt.savefig(title.replace(" ", "_"))

    return


def plot_bic_chart(figNum, bic, cvTypes, components, title):

    bars = []
    colors = itertools.cycle(['navy', 'turquoise', 'cornflowerblue', 'darkorange'])

    plt.figure(figNum)

    for i, (cv, color) in enumerate(zip(cvTypes, colors)):
        xpos = np.array(components) + .2 * (i - 2)
        bars.append(plt.bar(xpos, bic[i * len(components) : (i + 1) * len(components)], width=.2, color=color))

    plt.legend([b[0] for b in bars], cvTypes, loc="upper left")
    plt.xlabel("Number of Components")
    plt.ylabel("Average BIC Value")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(title.replace(" ", "_"))

    return

def plot_eigenvalues(figNum, pca, title, bins):

    plt.figure(figNum)
    plt.title(title)
    plt.xlabel('Eigenvalue')
    plt.ylabel('Number of Occurrences')

    for count, i in enumerate(pca.components_):
        plt.hist(i, bins, alpha=0.5, label=str(count + 1))

    plt.legend(loc='best')
    plt.savefig(title.replace(" ", "_"))

    return


def plot_kurtosis(figNum, ica, title, bins):

    plt.figure(figNum)
    plt.title(title)
    plt.xlabel('Value')
    plt.ylabel('Number of Occurrences')

    for count, i in enumerate(ica.components_):
        plt.hist(i, bins, alpha=0.5, label=str(count + 1))
        print "Component " + str(count + 1) + " Kurtosis: " + str(stats.kurtosis(i))

    plt.legend(loc='best')
    plt.savefig(title.replace(" ", "_"))

    return

def plot_random_projection(figNum, rp, title, bins):

    plt.figure(figNum)
    plt.title(title)
    plt.xlabel('Value')
    plt.ylabel('Number of Occurrences')

    for count, i in enumerate(rp.components_):
        plt.hist(i, bins, alpha=0.5, label=str(count + 1))

    plt.legend(loc='best')
    plt.savefig(title.replace(" ", "_"))

    return

def plot_factor_analysis(figNum, fa, title, bins):

    plt.figure(figNum)
    plt.title(title)
    plt.xlabel('Value')
    plt.ylabel('Number of Occurrences')

    for count, i in enumerate(fa.components_):
        plt.hist(i, bins, alpha=0.5, label=str(count + 1))

    plt.legend(loc='best')
    plt.savefig(title.replace(" ", "_"))

    return


def plot_learning_curve(estimator, x, y, title, train_sizes=np.linspace(.1, 0.9, 5), ylim=None):

    cv = ShuffleSplit(n_splits=5, test_size=0.2, random_state=0)

    plt.figure()
    plt.grid()
    plt.title(title)
    plt.xlabel("Training Examples")
    plt.ylabel("Accuracy Score")

    if ylim is not None:
        plt.ylim(*ylim)

    train_sizes, train_scores, test_scores = learning_curve(estimator, x, y, cv=cv,
                                                            n_jobs=1, train_sizes=train_sizes)

    train_scores_mean = np.mean(train_scores, axis=1)
    train_scores_std = np.std(train_scores, axis=1)
    test_scores_mean = np.mean(test_scores, axis=1)
    test_scores_std = np.std(test_scores, axis=1)

    plt.plot(train_sizes, train_scores_mean, 'o-', color="r", label="Training Score")
    plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                     train_scores_mean + train_scores_std, alpha=0.1, color="r")

    plt.plot(train_sizes, test_scores_mean, 'o-', color="g", label="Cross-validation Score")
    plt.fill_between(train_sizes, test_scores_mean - test_scores_std,
                     test_scores_mean + test_scores_std, alpha=0.1, color="g")

    plt.legend(loc="best")
    plt.savefig(title.replace(" ", "_").replace("(", "").replace(")", ""))

    return
