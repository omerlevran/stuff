import UnsupervisedLearning as ul
import Util as util
import Plot as plot

if __name__ == "__main__":

    xLetter, yLetter = util.getLetterData()   # extract letter recognition dataset
    xSpam, ySpam = util.getSpamData()         # extract email spam dataset

    # k Means Clustering Algorithm
    print "k Means Clustering"

    letterKmeans = ul.kMeans(xLetter, yLetter, 11, "letter", 0,
                             "k Means Inertia (Letter Recognition)", "k Means Silhouette Score (Letter Recognition)",
                             [1, 12, 120000, 220000], [1, 12, 0.1, 0.2], range(2, 12))

    spamKmeans = ul.kMeans(xSpam, ySpam, 2, "spam", 3,
                           "k Means Inertia (Spam E-mail)", "k Means Silhouette Score (Spam E-mail)",
                           [1, 12, 150000, 200000], [1, 12, 0.0, 0.8], range(2, 12))

    # Estimation Maximization Algorithm
    print "Estimation Maximization"

    letterExpmax = ul.expectationMax(xLetter, yLetter, 11, "full", "letter",
                                     5, "Expectation Maximization BIC Value (Letter Recognition)", range(2,12))

    spamExpmax = ul.expectationMax(xSpam, ySpam, 10, "diag", "spam",
                                   6, "Expectation Maximization BIC Value (Spam E-mail)", range(2,12))

    # PCA Algorithm
    print "PCA"

    letterPca = ul.pcaAlgorithm(xLetter, "letter")
    letterKmeans = ul.kMeans(letterPca, yLetter, 12, "letter", 9,
                             "k Means Inertia PCA (Letter Recognition)", "k Means Silhouette Score PCA (Letter Recognition)",
                             [1, 13, 100000, 200000], [1, 13, 0.0, 0.2], range(2,13))

    spamPca = ul.pcaAlgorithm(xSpam, "spam")
    spamKmeans = ul.kMeans(spamPca, ySpam, 2, "spam", 11,
                           "k Means Inertia PCA (Spam E-mail)", "k Means Silhouette Score PCA (Spam E-mail)",
                           [1, 13, 0, 5500], [1, 13, 0.55, 1.0], range(2,13))

    letterExpmax = ul.expectationMax(letterPca, yLetter, 11, "full", "letter", 13,
                                     "Expectation Maximization BIC Value PCA (Letter Recognition)", range(2,13))

    spamExpmax = ul.expectationMax(spamPca, ySpam, 10, "full", "spam", 14,
                                   "Expectation Maximization BIC Value PCA (Spam E-mail)", range(2,13))

    # ICA Algorithm
    print "ICA"

    letterIca = ul.icaAlgorithm(xLetter, "letter", 12)
    letterKmeans = ul.kMeans(letterIca, yLetter, 12, "letter", 17,
                             "k Means Inertia ICA (Letter Recognition)", "k Means Silhouette Score ICA (Letter Recognition)",
                             [1, 13, 100000, 200000], [1, 13, 0.0, 0.2], range(2,13))

    spamIca = ul.icaAlgorithm(xSpam, "spam", 2)
    spamKmeans = ul.kMeans(spamIca, ySpam, 2, "spam", 19,
                           "k Means Inertia ICA (Spam E-mail)", "k Means Silhouette Score ICA (Spam E-mail)",
                           [1, 13, 0, 5500], [1, 13, 0.55, 1.0], range(2,13))

    letterExpmax = ul.expectationMax(letterIca, yLetter, 12, "full", "letter", 21,
                                     "Expectation Maximization BIC Value ICA (Letter Recognition)", range(2,13))

    spamExpmax = ul.expectationMax(spamIca, ySpam, 10, "spherical", "spam", 22,
                                   "Expectation Maximization BIC Value ICA (Spam E-mail)", range(2,13))

    # Randomized Projections
    print "Randomized Projection"

    for i in range(4):
        letterRp = ul.randProjAlgorithm(xLetter, "letter", 12, i)

    letterKmeans = ul.kMeans(letterRp, yLetter, 12, "letter", 22,
                             "k Means Inertia RP (Letter Recognition)", "k Means Silhouette Score RP (Letter Recognition)",
                             [1, 13, 60000, 170000], [1, 13, 0.1, 0.25], range(2,13))

    spamRp = ul.randProjAlgorithm(xSpam, "spam", 2, None)
    spamKmeans = ul.kMeans(spamRp, ySpam, 2, "spam", 24,
                           "k Means Inertia RP (Spam E-mail)", "k Means Silhouette Score RP (Spam E-mail)",
                           [1, 13, 0, 4500], [1, 13, 0.55, 1.0], range(2,13))

    letterExpmax = ul.expectationMax(letterRp, yLetter, 12, "full", "letter", 26,
                                     "Expectation Maximization BIC Value RP (Letter Recognition)", range(2,13))

    spamExpmax = ul.expectationMax(spamRp, ySpam, 10, "full", "spam", 27,
                                   "Expectation Maximization BIC Value RP (Spam E-mail)", range(2,13))

    # Factor Analysis Algorithm
    print "Factor Analysis"

    letterFa = ul.factorAnalysis(xLetter, "letter", 12)
    letterKmeans = ul.kMeans(letterFa, yLetter, 12, "letter", 22,
                             "k Means Inertia FA (Letter Recognition)", "k Means Silhouette Score FA (Letter Recognition)",
                             [1, 13, 100000, 200000], [1, 13, 0.0, 0.15], range(2,13))

    spamFa = ul.factorAnalysis(xSpam, "spam", 2)
    spamKmeans = ul.kMeans(spamFa, ySpam, 2, "spam", 24,
                           "k Means Inertia FA (Spam E-mail)", "k Means Silhouette Score FA (Spam E-mail)",
                           [1, 13, 0, 6000], [1, 13, 0.55, 1.0], range(2,13))

    letterExpmax = ul.expectationMax(letterFa, yLetter, 12, "full", "letter", 26,
                                     "Expectation Maximization BIC Value FA (Letter Recognition)", range(2,13))

    spamExpmax = ul.expectationMax(spamFa, ySpam, 10, "full", "spam", 27,
                                   "Expectation Maximization BIC Value FA (Spam E-mail)", range(2,13))

    # Neural Network
    print "Neural Network"

    nn = ul.neuralNetwork(spamPca, spamIca, spamRp, spamFa, ySpam)
