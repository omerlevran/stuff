from sklearn import cluster
from sklearn import mixture
from sklearn import decomposition
from sklearn import random_projection
from sklearn import metrics
from sklearn import neural_network

from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import ShuffleSplit

import Plot as plot
import Util as util

import matplotlib.pyplot as plt
import numpy as np
import time

# Clustering Algorithms

def kMeans(xData, yData, k, dataset, figNum, titleOne, titleTwo, axesOne, axesTwo, range):

    # scale data
    scale = StandardScaler()
    scale.fit(xData)
    x = scale.transform(xData)

    clusters = []
    inertias = []
    silhouettes = []

    # train over different k clusters
    for kVal in range:
        cv = ShuffleSplit(n_splits=5, test_size=0.2) # five-fold cross-validation
        km = cluster.KMeans(n_clusters=kVal)

        totalTrainTime = 0
        totalTestTime = 0
        totalInertia = 0
        totalSilhouette = 0

        for trainIndices, testIndices in cv.split(x): # repeated five times
            trainSet = []
            testSet = []

            # convert indices to actual instances
            for trainIndex in trainIndices:
                trainSet.append(x[trainIndex])

            for testIndex in testIndices:
                testSet.append(x[testIndex])

            # build model
            startTrain = time.time()
            model = km.fit(trainSet)
            endTrain = time.time()
            trainTime = endTrain - startTrain

            # test model
            startTest = time.time()
            clusterLabels = km.predict(testSet)
            endTest = time.time()
            testTime = endTest - startTest

            score = silhouette_score(trainSet, model.labels_, metric="euclidean")

            totalTrainTime += trainTime
            totalTestTime += testTime
            totalInertia += model.inertia_
            totalSilhouette += score

        # value averages for current kVal
        avgTrainTime = totalTrainTime / 5.0
        avgTestTime = totalTestTime / 5.0
        avgInertia = totalInertia / 5.0
        avgSilhouette = totalSilhouette / 5.0

        clusters.append(kVal)
        inertias.append(avgInertia)
        silhouettes.append(avgSilhouette)

        print "Number of Clusters: " + str(kVal)
        print "Average Train Time: " + str(avgTrainTime)
        print "Average Test Time: " + str(avgTestTime)
        print "Average Inertia: " + str(avgInertia)
        print "Average Silhouette: " + str(avgSilhouette)
        print ""

    plot.plot_inertia_curve(figNum, clusters, inertias, axesOne, titleOne)
    plot.plot_silhouettes_curve(figNum + 1, clusters, silhouettes, axesTwo, titleTwo)

    ###########################

    # 80% training, 20% testing on optimal k value
    training = xData[0 : int(len(xData) * 0.8)]
    testingX = xData[int(len(xData) * 0.80) : len(xData) + 1]
    testingY = yData[int(len(yData) * 0.80) : len(yData) + 1]

    km = cluster.KMeans(n_clusters=k)
    km.fit(training)
    testLabels = km.predict(testingX)

    contingencyMatrix = metrics.cluster.contingency_matrix(testingY, testLabels)
    purity = np.sum(np.amax(contingencyMatrix, axis=0)) / float(np.sum(contingencyMatrix))

    print "Cluster Purity: " + str(purity)
    print "--------------------------------------"
    print ""

    return

def expectationMax(xData, yData, numComponents, covar, dataset, figNum, title, range):

    # scale data
    scale = StandardScaler()
    scale.fit(xData)
    x = scale.transform(xData)

    bic = []
    cvTypes = ['spherical', 'tied', 'diag', 'full']
    components = range

    for cv in cvTypes: # iterate over covariance types
        print "Covariance Type: " + cv

        for n in components: # train over different number of components
            crossV = ShuffleSplit(n_splits=5, test_size=0.2) # five-fold cross-validation
            gmm = mixture.GaussianMixture(n_components=n, covariance_type=cv)

            totalTrainTime = 0
            totalTestTime = 0
            totalBic = 0

            for trainIndices, testIndices in crossV.split(x): # repeated five times
                trainSet = []
                testSet = []

                # convert indices to actual instances
                for trainIndex in trainIndices:
                    trainSet.append(x[trainIndex])

                for testIndex in testIndices:
                    testSet.append(x[testIndex])

                # build model
                startTrain = time.time()
                model = gmm.fit(trainSet)
                endTrain = time.time()
                trainTime = endTrain - startTrain

                # test model
                startTest = time.time()
                testBic = gmm.bic(np.asarray(testSet))
                endTest = time.time()
                testTime = endTest - startTest

                totalTrainTime += trainTime
                totalTestTime += testTime
                totalBic += testBic

            # value averages for current number of components
            avgTrainTime = totalTrainTime / 5.0
            avgTestTime = totalTestTime / 5.0
            avgBic = totalBic / 5.0

            bic.append(avgBic)

            print "Number of Clusters: " + str(n)
            print "Average Train Time: " + str(avgTrainTime)
            print "Average Test Time: " + str(avgTestTime)
            print "Average BIC: " + str(avgBic)
            print ""

        print "---------------------------"
        print ""

    plot.plot_bic_chart(figNum, bic, cvTypes, components, title)

    ###########################

    # obtain purity score for components
    training = xData[0 : int(len(xData) * 0.8)]
    testingX = xData[int(len(xData) * 0.80) : len(xData) + 1]
    testingY = yData[int(len(yData) * 0.80) : len(yData) + 1]

    gmm = mixture.GaussianMixture(n_components=numComponents, covariance_type=covar)
    gmm.fit(training)
    testLabels = gmm.predict(testingX)

    contingencyMatrix = metrics.cluster.contingency_matrix(testingY, testLabels)
    purity = np.sum(np.amax(contingencyMatrix, axis=0)) / float(np.sum(contingencyMatrix))

    print "Component Purity: " + str(purity)
    print "--------------------------------------"
    print ""

    return


# Dimensionality Reduction Algorithms

def pcaAlgorithm(xData, dataset):

    # explain 95% of variance
    pca = decomposition.PCA(n_components=0.95, svd_solver='full')
    pca.fit(xData)

    if dataset == "letter":

        bins = np.linspace(-1, 1, 100)
        plot.plot_eigenvalues(7, pca, "PCA Distribution (Letter Recognition)", bins)

    elif dataset == "spam":

        bins = np.linspace(-0.001, 0.001, 100)
        plot.plot_eigenvalues(8, pca, "PCA Distribution (Spam E-mail)", bins)

    print "Number of Components to Explain 95% Variance: " + str(pca.n_components_)
    print "Explained Variance Ratios:"

    for count, i in enumerate(pca.explained_variance_ratio_):
        print "Component " + str(count + 1) + ": " + str(round(i * 100, 2)) + "%"

    print "--------------------------------------"
    print ""

    return pca.transform(xData)


def icaAlgorithm(xData, dataset, numComponents):

    ica = decomposition.FastICA(n_components=numComponents)
    ica.fit(xData)

    if dataset == "letter":
        bins = np.linspace(-0.005, 0.005, 100)
        plot.plot_kurtosis(15, ica, "ICA Distribution (Letter Recognition)", bins)

    elif dataset == "spam":
        bins = np.linspace(-.00004, .00004, 100)
        plot.plot_kurtosis(16, ica, "ICA Distribution (Spam E-mail)", bins)

    print "--------------------------------------"
    print ""

    return ica.transform(xData)

def randProjAlgorithm(xData, dataset, numComponents, iter):

    rp = random_projection.GaussianRandomProjection(n_components=numComponents)
    rp.fit(xData)

    if dataset == "letter":
        bins = np.linspace(-1, 1, 100)
        plot.plot_random_projection(17 + iter, rp, "Random Projection Distribution " + str(iter + 1) + " (Letter Recognition)", bins)
        print "Variance: " + str(np.var(rp.components_))

    elif dataset == "spam":
        bins = np.linspace(-1, 1, 100)
        plot.plot_random_projection(21, rp, "Random Projection Distribution (Spam E-mail)", bins)
        print "Variance: " + str(np.var(rp.components_))

    print "--------------------------------------"
    print ""

    return rp.transform(xData)

def factorAnalysis(xData, dataset, numComponents):

    fa = decomposition.FactorAnalysis(n_components=numComponents)
    fa.fit(xData)

    if dataset == "letter":
        bins = np.linspace(-1, 1, 100)
        plot.plot_factor_analysis(28, fa, "Factor Analysis Distribution (Letter Recognition)", bins)

    elif dataset == "spam":
        bins = np.linspace(-0.5, 0.5, 100)
        plot.plot_factor_analysis(29, fa, "Factor Analysis Distribution (Spam E-mail)", bins)

    print "--------------------------------------"
    print ""

    return fa.transform(xData)

def neuralNetwork(pcaData, icaData, rpData, faData, yData):

    nn = neural_network.MLPClassifier(hidden_layer_sizes=(49,), activation="tanh")
    km = cluster.KMeans(n_clusters=2)
    gmm = mixture.GaussianMixture(n_components=10, covariance_type="diag")

    # neural network dimensionality reduction
    print "Neural Network Dimensionality Reduction"

    start = time.time()
    plot.plot_learning_curve(nn, pcaData, yData, "PCA Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "PCA Convergence Time: " + str(end - start)

    start = time.time()
    plot.plot_learning_curve(nn, icaData, yData, "ICA Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "ICA Convergence Time: " + str(end - start)

    start = time.time()
    plot.plot_learning_curve(nn, rpData, yData, "RP Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "RP Convergence Time: " + str(end - start)

    start = time.time()
    plot.plot_learning_curve(nn, faData, yData, "FA Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "FA Convergence Time: " + str(end - start)

    print "--------------------------------------"
    print ""

    # neural network cluster dimensionality reduction (kmeans)
    print "Neural Network KM Clustering"

    km.fit(pcaData)
    km_clusters_pca = km.predict(pcaData)

    km.fit(icaData)
    km_clusters_ica = km.predict(icaData)

    km.fit(rpData)
    km_clusters_rp = km.predict(rpData)

    km.fit(faData)
    km_clusters_fa = km.predict(faData)

    pcaArr = []
    icaArr = []
    rpArr = []
    faArr = []

    for i in range(len(pcaData)):
        pcaArr.append(np.append(pcaData[i], km_clusters_pca[i]))

    for i in range(len(icaData)):
        icaArr.append(np.append(icaData[i], km_clusters_ica[i]))

    for i in range(len(rpData)):
        rpArr.append(np.append(rpData[i], km_clusters_rp[i]))

    for i in range(len(faData)):
        faArr.append(np.append(faData[i], km_clusters_fa[i]))

    start = time.time()
    plot.plot_learning_curve(nn, pcaArr, yData, "Kmeans PCA Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "Kmeans PCA Convergence Time: " + str(end - start)

    start = time.time()
    plot.plot_learning_curve(nn, icaArr, yData, "Kmeans ICA Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "Kmeans ICA Convergence Time: " + str(end - start)

    start = time.time()
    plot.plot_learning_curve(nn, rpArr, yData, "Kmeans RP Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "Kmeans RP Convergence Time: " + str(end - start)

    start = time.time()
    plot.plot_learning_curve(nn, faArr, yData, "Kmeans FA Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "Kmeans FA Convergence Time: " + str(end - start)

    print "--------------------------------------"
    print ""

    # neural network cluster dimensionality reduction (estimation maximization)
    print "Neural Network EM Clustering"

    gmm.fit(pcaData)
    gmm_clusters_pca = gmm.predict(pcaData)

    gmm.fit(icaData)
    gmm_clusters_ica = gmm.predict(icaData)

    gmm.fit(rpData)
    gmm_clusters_rp = gmm.predict(rpData)

    gmm.fit(faData)
    gmm_clusters_fa = gmm.predict(faData)

    pcaArr = []
    icaArr = []
    rpArr = []
    faArr = []

    for i in range(len(pcaData)):
        pcaArr.append(np.append(pcaData[i], gmm_clusters_pca[i]))

    for i in range(len(icaData)):
        icaArr.append(np.append(icaData[i], gmm_clusters_ica[i]))

    for i in range(len(rpData)):
        rpArr.append(np.append(rpData[i], gmm_clusters_rp[i]))

    for i in range(len(faData)):
        faArr.append(np.append(faData[i], gmm_clusters_fa[i]))

    start = time.time()
    plot.plot_learning_curve(nn, pcaArr, yData, "EM PCA Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "Estimation Maximization PCA Convergence Time: " + str(end - start)

    start = time.time()
    plot.plot_learning_curve(nn, icaArr, yData, "EM ICA Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "Estimation Maximization ICA Convergence Time: " + str(end - start)

    start = time.time()
    plot.plot_learning_curve(nn, rpArr, yData, "EM RP Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "Estimation Maximization RP Convergence Time: " + str(end - start)

    start = time.time()
    plot.plot_learning_curve(nn, faArr, yData, "EM FA Neural Network (Spam E-mail)", ylim=(0.5, 1.0))
    end = time.time()
    print "Estimation Maximization FA Convergence Time: " + str(end - start)

    print "--------------------------------------"
    print ""

    return
