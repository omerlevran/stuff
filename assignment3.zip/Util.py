import random

def getLetterData(fileName="data/letter-recognition.data.txt", limit=100000):
    data = open(fileName)

    x = []
    y = []

    for line in data:
        line_split = line.split(',')
        x.append([float(i) for i in line_split[1:]])
        y.append(line_split[0])

    return (x, y)

def getSpamData(fileName="data/spambase.data.txt", limit=100000):
    data = open(fileName)

    x = []
    y = []

    shuffled = []

    for line in data:
        shuffled.append([float(i) for i in line.split(',')])

    random.shuffle(shuffled)

    for i in shuffled:
        x.append(i[:-1])
        y.append(int(i[-1]))

    return (x, y)
