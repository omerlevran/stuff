Assignment 3
Omer Lev-ran
olr3
Credit to jtay, cam, and corey since I used alot of their code

# How to run

Download the folder from the google one drive

cd into the directory

Pip install requirements `pip3 install -r requirements.txt`

Run `python3 run.py

Output be in the figures folder